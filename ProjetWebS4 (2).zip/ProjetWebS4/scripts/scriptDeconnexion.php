<?php 

	session_destroy();
	header("Location:/ProjetWebS4/index.php");

?>
